var structled__color__component__format__t_1_1format__layout =
[
    [ "b_pos", "structled__color__component__format__t_1_1format__layout.html#ac2ec15238cda42e96a8b7eadfcf98d5d", null ],
    [ "g_pos", "structled__color__component__format__t_1_1format__layout.html#ab31530265f76a1e677f9bde230d8e72e", null ],
    [ "num_components", "structled__color__component__format__t_1_1format__layout.html#a44f72facd9eafbec1abdea93a796bece", null ],
    [ "r_pos", "structled__color__component__format__t_1_1format__layout.html#a95b120b5390a23950a581a652895dea4", null ],
    [ "reserved", "structled__color__component__format__t_1_1format__layout.html#a03da1338f5244552e5952cae2cdfcb28", null ],
    [ "w_pos", "structled__color__component__format__t_1_1format__layout.html#aebc169b859ae6853c146b3faf751088c", null ]
];