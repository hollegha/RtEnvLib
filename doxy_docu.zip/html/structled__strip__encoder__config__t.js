var structled__strip__encoder__config__t =
[
    [ "led_model", "structled__strip__encoder__config__t.html#a430d07ba9efa456d9adc58215ada7098", null ],
    [ "resolution", "structled__strip__encoder__config__t.html#a9ab68c581424c5fbd050fa68d679f063", null ]
];