var searchData=
[
  ['r_5fpos_0',['r_pos',['../structled__color__component__format__t_1_1format__layout.html#a95b120b5390a23950a581a652895dea4',1,'led_color_component_format_t::format_layout']]],
  ['rangeclip_1',['RangeClip',['../class_range_clip.html',1,'']]],
  ['ratelim_2',['RateLim',['../class_rate_lim.html',1,'']]],
  ['rcservo_3',['RcServo',['../class_rc_servo.html',1,'']]],
  ['refresh_4',['refresh',['../structled__strip__t.html#a31295f688217f75eaf4639685e69e12b',1,'led_strip_t']]],
  ['reserved_5',['reserved',['../structled__color__component__format__t_1_1format__layout.html#a03da1338f5244552e5952cae2cdfcb28',1,'led_color_component_format_t::format_layout']]],
  ['resolution_6',['resolution',['../structled__strip__encoder__config__t.html#a9ab68c581424c5fbd050fa68d679f063',1,'led_strip_encoder_config_t']]],
  ['resolution_5fhz_7',['resolution_hz',['../structled__strip__rmt__config__t.html#ac0a5bfa5fdd021a41de4e6dfaf9b1113',1,'led_strip_rmt_config_t']]],
  ['rmt_5fled_5fstrip_5fencoder_5ft_8',['rmt_led_strip_encoder_t',['../structrmt__led__strip__encoder__t.html',1,'']]]
];
