var searchData=
[
  ['clear_0',['clear',['../structled__strip__t.html#ac1b971ea5d539d5b21953556fb453d3c',1,'led_strip_t']]],
  ['clk_5fsrc_1',['clk_src',['../structled__strip__rmt__config__t.html#aadffab2adfd58f5bd1c99ed36dc371c6',1,'led_strip_rmt_config_t::clk_src'],['../structled__strip__spi__config__t.html#a35352b41eab07bfd2617813122f675df',1,'led_strip_spi_config_t::clk_src']]],
  ['color_5fcomponent_5fformat_2',['color_component_format',['../structled__strip__config__t.html#a6a4e80c18b9c6c1855c8c3aa8a65d392',1,'led_strip_config_t']]]
];
