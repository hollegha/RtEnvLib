var searchData=
[
  ['set_5fpixel_0',['set_pixel',['../structled__strip__t.html#a634f88b9e82155f97b6262e0b49565ef',1,'led_strip_t']]],
  ['set_5fpixel_5frgbw_1',['set_pixel_rgbw',['../structled__strip__t.html#abe646a862976a83e5eaac972d043787e',1,'led_strip_t']]],
  ['spi_5fbus_2',['spi_bus',['../structled__strip__spi__config__t.html#a0900424264bc59ab6915c9936532b032',1,'led_strip_spi_config_t']]],
  ['strip_5fgpio_5fnum_3',['strip_gpio_num',['../structled__strip__config__t.html#a606308f9a50c24ce5ea5d55b26502313',1,'led_strip_config_t']]]
];
