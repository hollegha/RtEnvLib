var searchData=
[
  ['num_5fcomponents_0',['num_components',['../structled__color__component__format__t_1_1format__layout.html#a44f72facd9eafbec1abdea93a796bece',1,'led_color_component_format_t::format_layout']]]
];
