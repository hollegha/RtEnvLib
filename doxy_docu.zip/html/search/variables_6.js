var searchData=
[
  ['led_5fmodel_0',['led_model',['../structled__strip__encoder__config__t.html#a430d07ba9efa456d9adc58215ada7098',1,'led_strip_encoder_config_t::led_model'],['../structled__strip__config__t.html#a37c4df94f484de3c6941e6580a4e91ab',1,'led_strip_config_t::led_model']]]
];
