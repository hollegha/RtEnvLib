var searchData=
[
  ['format_5flayout_0',['format_layout',['../structled__color__component__format__t_1_1format__layout.html',1,'led_color_component_format_t']]]
];
