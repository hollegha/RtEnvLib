var searchData=
[
  ['r_5fpos_0',['r_pos',['../structled__color__component__format__t_1_1format__layout.html#a95b120b5390a23950a581a652895dea4',1,'led_color_component_format_t::format_layout']]],
  ['refresh_1',['refresh',['../structled__strip__t.html#a31295f688217f75eaf4639685e69e12b',1,'led_strip_t']]],
  ['reserved_2',['reserved',['../structled__color__component__format__t_1_1format__layout.html#a03da1338f5244552e5952cae2cdfcb28',1,'led_color_component_format_t::format_layout']]],
  ['resolution_3',['resolution',['../structled__strip__encoder__config__t.html#a9ab68c581424c5fbd050fa68d679f063',1,'led_strip_encoder_config_t']]],
  ['resolution_5fhz_4',['resolution_hz',['../structled__strip__rmt__config__t.html#ac0a5bfa5fdd021a41de4e6dfaf9b1113',1,'led_strip_rmt_config_t']]]
];
