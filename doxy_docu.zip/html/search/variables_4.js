var searchData=
[
  ['g_5fpos_0',['g_pos',['../structled__color__component__format__t_1_1format__layout.html#ab31530265f76a1e677f9bde230d8e72e',1,'led_color_component_format_t::format_layout']]]
];
