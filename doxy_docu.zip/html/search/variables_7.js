var searchData=
[
  ['max_5fleds_0',['max_leds',['../structled__strip__config__t.html#a9d2cc8718131d9a9e3dd15d8496e7941',1,'led_strip_config_t']]],
  ['mem_5fblock_5fsymbols_1',['mem_block_symbols',['../structled__strip__rmt__config__t.html#ae261b7a06d5971e52679eb58b91f4a43',1,'led_strip_rmt_config_t']]]
];
