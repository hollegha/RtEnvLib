var searchData=
[
  ['del_0',['del',['../structled__strip__t.html#a77337bce36b273599b3cbaafdc8821b0',1,'led_strip_t']]]
];
