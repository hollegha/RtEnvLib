var searchData=
[
  ['setpow2_0',['setPow2',['../class_motor.html#a72186366cf51c159b913c68c9cd6157f',1,'Motor']]]
];
