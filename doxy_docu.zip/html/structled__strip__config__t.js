var structled__strip__config__t =
[
    [ "led_strip_extra_flags", "structled__strip__config__t_1_1led__strip__extra__flags.html", "structled__strip__config__t_1_1led__strip__extra__flags" ],
    [ "color_component_format", "structled__strip__config__t.html#a6a4e80c18b9c6c1855c8c3aa8a65d392", null ],
    [ "flags", "structled__strip__config__t.html#a941a2be212342c87539f2f7a6bced989", null ],
    [ "led_model", "structled__strip__config__t.html#a37c4df94f484de3c6941e6580a4e91ab", null ],
    [ "max_leds", "structled__strip__config__t.html#a9d2cc8718131d9a9e3dd15d8496e7941", null ],
    [ "strip_gpio_num", "structled__strip__config__t.html#a606308f9a50c24ce5ea5d55b26502313", null ]
];