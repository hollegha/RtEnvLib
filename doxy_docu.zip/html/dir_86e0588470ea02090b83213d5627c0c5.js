var dir_86e0588470ea02090b83213d5627c0c5 =
[
    [ "commu", "dir_71f824d1fcec722e08e87a62617bb383.html", "dir_71f824d1fcec722e08e87a62617bb383" ],
    [ "core", "dir_97eca45462a552f50d361a5db064b7fe.html", "dir_97eca45462a552f50d361a5db064b7fe" ],
    [ "led_strip", "dir_45cc25a0d794e3828e4fe4fa15584e3b.html", "dir_45cc25a0d794e3828e4fe4fa15584e3b" ]
];