var structled__strip__spi__config__t =
[
    [ "clk_src", "structled__strip__spi__config__t.html#a35352b41eab07bfd2617813122f675df", null ],
    [ "flags", "structled__strip__spi__config__t.html#a603fd7bba3d32ca5245b437acb4c46db", null ],
    [ "spi_bus", "structled__strip__spi__config__t.html#a0900424264bc59ab6915c9936532b032", null ],
    [ "with_dma", "structled__strip__spi__config__t.html#a627ea85494e4892b1daf4b6832992e00", null ]
];