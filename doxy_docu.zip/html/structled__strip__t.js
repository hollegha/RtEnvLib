var structled__strip__t =
[
    [ "clear", "structled__strip__t.html#ac1b971ea5d539d5b21953556fb453d3c", null ],
    [ "del", "structled__strip__t.html#a77337bce36b273599b3cbaafdc8821b0", null ],
    [ "refresh", "structled__strip__t.html#a31295f688217f75eaf4639685e69e12b", null ],
    [ "set_pixel", "structled__strip__t.html#a634f88b9e82155f97b6262e0b49565ef", null ],
    [ "set_pixel_rgbw", "structled__strip__t.html#abe646a862976a83e5eaac972d043787e", null ]
];