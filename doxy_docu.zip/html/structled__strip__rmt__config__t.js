var structled__strip__rmt__config__t =
[
    [ "led_strip_rmt_extra_config", "structled__strip__rmt__config__t_1_1led__strip__rmt__extra__config.html", "structled__strip__rmt__config__t_1_1led__strip__rmt__extra__config" ],
    [ "clk_src", "structled__strip__rmt__config__t.html#aadffab2adfd58f5bd1c99ed36dc371c6", null ],
    [ "flags", "structled__strip__rmt__config__t.html#a3b4179e0521ed754142ef558a6c5c94b", null ],
    [ "mem_block_symbols", "structled__strip__rmt__config__t.html#ae261b7a06d5971e52679eb58b91f4a43", null ],
    [ "resolution_hz", "structled__strip__rmt__config__t.html#ac0a5bfa5fdd021a41de4e6dfaf9b1113", null ]
];