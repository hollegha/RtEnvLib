var unionled__color__component__format__t =
[
    [ "format_layout", "structled__color__component__format__t_1_1format__layout.html", "structled__color__component__format__t_1_1format__layout" ],
    [ "format", "unionled__color__component__format__t.html#ae7119fc5e0d9d55d48a89b78c9698e5c", null ],
    [ "format_id", "unionled__color__component__format__t.html#a685288df6e707a15365838d4f08999ee", null ]
];