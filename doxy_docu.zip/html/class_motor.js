var class_motor =
[
    [ "Motor", "class_motor.html#a112e932ba73f0d5beca6b93db8d419b1", null ],
    [ "setPow2", "class_motor.html#a72186366cf51c159b913c68c9cd6157f", null ]
];